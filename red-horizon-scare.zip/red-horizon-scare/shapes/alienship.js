import {defs, tiny} from '../examples/common.js';

const {
    Shape,
} = tiny;
const {
    Capped_Cylinder, Cone_Tip, Subdivision_Sphere
} = defs;

// export class AlienShip extends Shape {
   
//     constructor() {
//         // Create a disk-shaped alien ship
//         super("position", "normal", "texture_coord");

//         Cone_Tip.prototype.make_flat_shaded_version().insert_transformed_copy_into(this, [0])

//     }
// }
